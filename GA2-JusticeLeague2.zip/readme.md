Group Assignment 2

							Justic League 2
							TIC-TAC-TOE GAME
Bhavya Kapoor
Chenfei Hu
Saher Anwar Ziauddin - B00853974 - Saher.Ziauddin@dal.ca
Abdalla Elsebai
Xue Wang B00799311 Email: xz569779@dal.ca
Yanhao Li B00821503 Email: yn527901@dal.ca

Summary:
This website incorporates the game TIC-TAC-TOE. You will be playing against a computer so you'll have to be tricky to win. The
game is played on a 3 by 3 table. You need to take turns putting marks on each cell of the table until you win, lose or draw. 
You win if you can get 3 'X' marks in a row, column or diagonally. If the computer succeeds then you lose, otherwise it's a draw.

Instructions:
- The game is played on a grid that's 3 squares by 3 squares.
- You are X, your friend (or the computer in this case) is O. Players take turns putting their marks in empty squares.
- The first player to get 3 of her marks in a row (up, down, across, or diagonally) is the winner.
- When all 9 squares are full, the game is over. If no player has 3 marks in a row, the game ends in a tie

Saher Anwar's Work:
I worked on the development on the nav bar, including styles and font. Designed the basic overall layout of the webpage. The rest
of the webpage's designed was done equally by the teammates (which is more than what I did). Furthermore, I designed the bottom 
half of the page which (the contacts section) which basically includes a list of the developers who helped create this website. It 
includes the person's name, a quote said by them, a link to their linkedIn profiles, a link to their Instagram and their email 
addresses. I have asked everybody to link their social media, add a quote and attach a picture of themselves if they're 
comfortable. Originally, I assigned this feature to Yanhao Li because she came quite late to the group's meeting. She had done part
of the feature but I just felt like I could add more to it so I somewhat revamped the code structure and included my extra details
to the feature there as well thus part of that feature's work also goes to Yanhao Li. Aside from that, I divided the work amongst 
the team and coordinated meetings. I also fixed the code problems by running the code through the online website checker, formatted
the code and cleaned up the CSS file. 

Citations:
Tic Tac Toe images: https://www.flaticon.com/premium-icon/tic-tac-toe_1175477
History of Tic Tac Toe: https://wonderopolis.org/wonder/how-old-is-tic-tac-toe
wallpaper: https://www.pinterest.com/pin/847732329830497612/
Xue's work reference: https://www.w3schools.com/html/html_images_background.asp 
Dark mode help reference: https://www.w3schools.com/howto/howto_js_toggle_dark_mode.asp

Xue's work:
I add a background image (dark mode is also worked) and some funny icons. I also implement one thing which is when the mouse hovers over, the top elements color changes to white.
Icons from: https://www.flaticon.com/
The background image from: https://www.pexels.com/photo/photo-of-white-wall-1484759/
My works reference from: https://www.w3schools.com/html/html_images_background.asp

Yanhao's work:
I designed the layout for the web. The author was placed at the bottom, which was later modified by Saher. I added some small icons. I adjusted the format of the list and changed the overall font to make the font look more comfortable. I also made some color changes in the details.
Yanhao's Source: https://www.flaticon.com/premium-icon/tic-tac-toe_1175477
Website used to help set up dark mode: https://www.w3schools.com/howto/howto_js_toggle_dark_mode.asp


