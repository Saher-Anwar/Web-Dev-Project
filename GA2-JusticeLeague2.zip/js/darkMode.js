function darkMode() {
  var darkModeToggle=document.body;
  darkModeToggle.classList.toggle("dark-mode");
}